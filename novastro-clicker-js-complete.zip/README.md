# Novastro Clicker JS Version

Terminal gerektirmeyen Vercel deploy uyumludur.